package com.example.hp.assignment4;

/**
 * Created by HP on 12/21/2017.
 */



public class MyEvents {
    int value;

    public MyEvents(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
